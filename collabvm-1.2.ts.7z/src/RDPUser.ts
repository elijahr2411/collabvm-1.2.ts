export default interface RDPUser {
    Username: string;
    Password: string;
}